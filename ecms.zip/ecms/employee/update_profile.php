<?php
session_start();
include('../db.php');

// Ensure employee is logged in
if (!isset($_SESSION['employee_id']) || $_SESSION['role'] != 'employee') {
    header('Location: ../login.php');
    exit();
}

$employee_id = $_SESSION['employee_id'];

// Fetch employee details
$query = "SELECT name, username, email, contact_no FROM employees WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $employee_id);
$stmt->execute();
$result = $stmt->get_result();
$employee = $result->fetch_assoc();
$stmt->close();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $contact_no = $_POST['contact_no'];
    $password = !empty($_POST['password']) ? password_hash($_POST['password'], PASSWORD_DEFAULT) : null;

    // Update query
    if ($password) {
        $update_query = "UPDATE employees SET name=?, username=?, email=?, contact_no=?, password=? WHERE id=?";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("sssssi", $name, $username, $email, $contact_no, $password, $employee_id);
    } else {
        $update_query = "UPDATE employees SET name=?, username=?, email=?, contact_no=? WHERE id=?";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("ssssi", $name, $username, $email, $contact_no, $employee_id);
    }

    if ($stmt->execute()) {
        echo "<script>alert('Profile updated successfully!'); window.location.href='my_profile.php';</script>";
    } else {
        echo "Error updating profile: " . $conn->error;
    }
    $stmt->close();
}
?>

<?php include('header.php'); ?>
<?php include('sidebar.php'); ?>

<div class="container mt-5" style="max-width: 600px;">
    <h2 class="text-center mb-4" style="font-weight: bold; color: #2c3e50;">Update Profile</h2>
    <div class="card shadow-lg p-4" style="border-radius: 15px; background: #ffffff;">

        <form method="POST">
            <div class="form-group">
                <label><strong>Name:</strong></label>
                <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($employee['name']); ?>" required>
            </div>

            <div class="form-group">
                <label><strong>Username:</strong></label>
                <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($employee['username']); ?>" required>
            </div>

            <div class="form-group">
                <label><strong>Email:</strong></label>
                <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($employee['email']); ?>" required>
            </div>

            <div class="form-group">
                <label><strong>Contact Number:</strong></label>
                <input type="text" name="contact_no" class="form-control" value="<?= htmlspecialchars($employee['contact_no']); ?>" required>
            </div>

            <div class="form-group">
                <label><strong>New Password (Leave blank to keep current password):</strong></label>
                <input type="password" name="password" class="form-control">
            </div>

            <div class="text-center mt-3">
                <button type="submit" class="btn btn-success" style="padding: 20px 20px; font-size: 16px; border-radius: 5px;">Update Profile</button>
            </div>
        </form>

    </div>
</div>

<?php include('footer.php'); ?>
