<?php 
session_start();
include('../db.php');

// Ensure employee is logged in
if (!isset($_SESSION['employee_id']) || $_SESSION['role'] != 'employee') {
    header('Location: ../login.php');
    exit();
}

$employee_id = $_SESSION['employee_id'];

// Fetch employee details using prepared statements
$emp_query = "SELECT name, designation, division, pin_no, dob, email AS email, contact_no FROM employees WHERE id = ? LIMIT 1";
$stmt = $conn->prepare($emp_query);
$stmt->bind_param("i", $employee_id);
$stmt->execute();
$emp_result = $stmt->get_result();
$employee = $emp_result->fetch_assoc();
$stmt->close();

if (!$employee) {
    die("Employee details not found.");
}
?>

<?php include('header.php'); ?>
<?php include('sidebar.php'); ?>

<div class="container mt-5" style="margin-left: 150px; max-width: 800px;">
    <h2 class="text-center mb-4" style="font-weight: bold; color: #2c3e50;">My Profile</h2>
    <div class="card shadow-lg p-4" style="border-radius: 15px; background: linear-gradient(145deg, #ffffff, #f0f0f0); box-shadow: 5px 5px 15px #d1d1d1, -5px -5px 15px #ffffff;">
        <p><strong>Name:</strong> <?php echo htmlspecialchars($employee['name']); ?></p>
        <p><strong>Designation:</strong> <?php echo htmlspecialchars($employee['designation']); ?></p>
        <p><strong>Division:</strong> <?php echo htmlspecialchars($employee['division']); ?></p>
        <p><strong>PIN Number:</strong> <?php echo htmlspecialchars($employee['pin_no']); ?></p>
        <p><strong>Date of Birth:</strong> <?php echo htmlspecialchars($employee['dob']); ?></p>
        <p><strong>Email :</strong> <?php echo htmlspecialchars($employee['email']); ?></p>
        <p><strong>Contact Number:</strong> <?php echo htmlspecialchars($employee['contact_no']); ?></p>
    </div>
</div>
<div class="text-center mt-4">
    <a href="update_profile.php" class="btn btn-primary" style="padding: 10px 20px; font-size: 16px; border-radius: 5px;">
        Update Profile
    </a>
</div>


<?php include('footer.php'); ?>
