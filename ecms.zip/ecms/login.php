<?php
session_start();
include('db.php'); // Database connection file

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    $role = isset($_POST['role']) ? trim($_POST['role']) : '';

    if (!empty($email) && !empty($password) && !empty($role)) {
        // Use prepared statement for security
        $query = "SELECT * FROM employees WHERE email = ? AND role = ? LIMIT 1";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "ss", $email, $role);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($result && mysqli_num_rows($result) == 1) {
            $employee = mysqli_fetch_assoc($result);

            $storedPassword = $employee['password'];

            // Check if password is plain text or hashed
            if ($storedPassword === $password || password_verify($password, $storedPassword)) {
                $_SESSION['employee_id'] = $employee['id'];
                $_SESSION['role'] = $employee['role'];

                if ($employee['role'] == 'admin') {
                    header('Location: ./adminLTE/dashboard.php');
                    exit();
                } elseif ($employee['role'] == 'employee') {
                    header('Location: ./employee/dashboard.php');
                    exit();
                }
            } else {
                $error = "Incorrect Password!";
            }
        } else {
            $error = "Invalid Email or Role!";
        }
    } else {
        $error = "All fields are required";
    }
}
?>

<?php include('header.php'); ?>
<style>
    
</style>

<section class="bg-light vh-100 d-flex">
    <div class="col-6 col-sm-8 col-md-6 col-lg-4 m-auto">
        <div class="card">
            <div class="card-body">
                <div class="border rounded-circle mx-auto d-flex" style="width:90px;height:90px">
                    <i class="fa fa-user text-dark fa-3x m-auto"></i>
                </div>
                <form action="" method="POST">
                    <h2 class="text-center mt-3">ECMS LOGIN</h2>
                    <?php if (isset($error)) echo "<p class='text-danger text-center'>$error</p>"; ?>
                    <div class="md-form">
                        <label for="email">Enter Email</label>
                        <input type="email" id="email" name="email" class="form-control" placeholder="example@domain.com" required>
                    </div>
                    <div class="md-form mt-3">
                        <label for="password">Your Password</label>
                        <input type="password" id="password" name="password" class="form-control" required>
                    </div>
                    <div class="mt-3">
                        <label for="role">Select Role</label>
                        <select id="role" name="role" class="form-control" required>
                            <option value="admin">Admin</option>
                            <option value="employee">Employee</option>
                        </select>
                    </div>
                    <div class="text-center mt-4">
                        <button class="btn btn-secondary" name="login">Login</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<?php include('footer.php'); ?>
