<?php
include '../db.php'; // Database connection

$id = 0;

// Check for ID in GET (when opening the form) or POST (when submitting)
if (isset($_GET['id'])) {
    $id = (int) $_GET['id'];
} elseif (isset($_POST['id'])) {
    $id = (int) $_POST['id'];
}

if ($id <= 0) {
    die("Invalid Employee ID.");
}

// Fetch employee details
$stmt = $conn->prepare("SELECT * FROM employees WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$employee = $result->fetch_assoc();
$stmt->close();

// Ensure employee data exists
if (!$employee) {
    die("Error: Employee not found.");
}

// Fetch training history
$training_query = "SELECT * FROM training_records WHERE employee_id = $id ORDER BY year DESC";
$training_result = mysqli_query($conn, $training_query);
$training_data = [];
while ($row = mysqli_fetch_assoc($training_result)) {
    $training_data[$row['year']][] = $row;
}

// Fetch training needs
$tni_query = "SELECT * FROM tni WHERE employee_id = $id";
$tni_result = mysqli_query($conn, $tni_query);
$tni = mysqli_fetch_assoc($tni_result);

// Handle form submission for updating employee details
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST['name'];
    $designation = $_POST['designation'];
    $division = $_POST['division'];
    $pin_no = $_POST['pin_no'];
    $email = $_POST['email'];
    $dob = $_POST['dob'];
    $contact_no = $_POST['contact_no'];

    // Update employee details in the database
    $stmt = $conn->prepare("UPDATE employees SET name=?, designation=?, division=?, pin_no=?, email=?, dob=?, contact_no=? WHERE id=?");
    $stmt->bind_param("sssssssi", $name, $designation, $division, $pin_no, $email, $dob, $contact_no, $id);
    
    if ($stmt->execute()) {
        echo "<script>alert('Employee updated successfully!'); window.location.href='../adminLTE/all_employees.php';</script>";
    } else {
        echo "Error updating record: " . $conn->error;
    }
    
    $stmt->close();
}
?>

<?php include('header.php'); ?>
<?php include('sidebar.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Employee</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 20px;
            padding: 20px;
        }
        h2 {
            text-align: center;
        }
        h2, h3, h5 {
            color: #333;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-row {
            display: flex;
            gap: 20px;
        }
        .form-row .form-group {
            flex: 1;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        select, input, textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .training-container {
            margin-top: 20px;
        }
        .training-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
        }
        .training-table th, .training-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        .training-table th {
            background: #007bff;
            color: white;
        }
        button {
            background: #007bff;
            color: white;
            border: none;
            margin-bottom: 8px;
            padding: 8px 12px;
            cursor: pointer;
            border-radius: 4px;
        }
        button:hover {
            background: #0056b3;
        }
        .btn-success {
            width: 100%;
            padding: 6px;
            margin: 5px;
            font-weight: bold;
            font-size: 20px;
        }
    </style>
    <script>
        function addTrainingRow(year) {
            var table = document.getElementById("training-" + year);
            var newRow = document.createElement("tr");
            newRow.innerHTML = `
                <td><input type="text" name="training_type_${year}[]" placeholder="Training Type"></td>
                <td><input type="text" name="course_name_${year}[]" placeholder="Course Name"></td>
                <td><input type="text" name="institute_${year}[]" placeholder="Institute"></td>
                <td><input type="text" name="duration_${year}[]" placeholder="Duration"></td>
                <td><button type="button" onclick="this.parentElement.parentElement.remove()">-</button></td>
            `;
            table.appendChild(newRow);
        }
    </script>
</head>
<body>

<h2><strong>Edit Employee Details</strong></h2>
<form action="edit_employee.php?id=<?= $id; ?>" method="POST">
    <input type="hidden" name="id" value="<?= $id; ?>">

    <section>
        <h3>Basic Information</h3>
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?= htmlspecialchars($employee['name']); ?>" required>
        </div>
        <div class="form-row">
            <div class="form-group"><label>Designation:</label>
                <input type="text" name="designation" value="<?= htmlspecialchars($employee['designation']); ?>" required>
            </div>
            <div class="form-group"><label>Division:</label>
                <input type="text" name="division" value="<?= htmlspecialchars($employee['division']); ?>" required>
            </div>
        </div>
             <div class="form-row">
                <div class="form-group"><label>PIN No:</label>
                <input type="text" name="pin_no" value="<?= htmlspecialchars($employee['pin_no']); ?>" required>
                </div>
                <div class="form-group"><label>Email:</label>
                <input type="email" name="email" value="<?= htmlspecialchars($employee['email']); ?>" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Date of Birth:</label>
                <input type="date" name="dob" value="<?= htmlspecialchars($employee['dob']); ?>" required>
                </div>
                <div class="form-group"><label>Contact No:</label>
                <input type="text" name="contact_no" value="<?= htmlspecialchars($employee['contact_no']); ?>" required>
                </div>
            </div>
    </section>

    <section>

<!-- Training History Container -->
<div class="training-container">
    <?php $years = [2024, 2023, 2022]; ?>
    <?php foreach ($years as $year): ?>
        <h4><?= $year; ?></h4>
        <table id="training-<?= $year; ?>" class="training-table">
            <tr>
                <th>Training Type</th>
                <th>Course Name</th>
                <th>Institute</th>
                <th>Duration</th>
                <th>Action</th>
            </tr>
            <?php if (isset($training_data[$year])): ?>
                <?php foreach ($training_data[$year] as $row): ?>
                    <tr>
                        <td><input type="text" name="training_type_<?= $year; ?>[]" value="<?= htmlspecialchars($row['training_type']); ?>"></td>
                        <td><input type="text" name="course_name_<?= $year; ?>[]" value="<?= htmlspecialchars($row['course_name']); ?>"></td>
                        <td><input type="text" name="institute_<?= $year; ?>[]" value="<?= htmlspecialchars($row['institute']); ?>"></td>
                        <td><input type="text" name="duration_<?= $year; ?>[]" value="<?= htmlspecialchars($row['duration']); ?>"></td>
                        <td><button type="button" onclick="this.parentElement.parentElement.remove()">-</button></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </table>
        <button type="button" onclick="addTrainingRow(<?= $year; ?>)">+ Add Training</button>
    <?php endforeach; ?>
</div>
</section>

<section>
    <h3>Training Needs</h3>
    <textarea name="training_need_1" rows="2"><?= isset($tni['training_need_1']) ? htmlspecialchars($tni['training_need_1']) : ''; ?></textarea>
    <textarea name="training_need_2" rows="2"><?= isset($tni['training_need_2']) ? htmlspecialchars($tni['training_need_2']) : ''; ?></textarea>
    <textarea name="training_need_3" rows="2"><?= isset($tni['training_need_3']) ? htmlspecialchars($tni['training_need_3']) : ''; ?></textarea>

    </section>
    <button class="btn btn-success" type="submit">Update Employee</button>
</form>

</body>
</html>

<?php include('footer.php'); ?>
